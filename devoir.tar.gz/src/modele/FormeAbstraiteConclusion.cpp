#include "FormeAbstraiteConclusion.hpp"

namespace sysexp
{
    namespace modele
    {

        FormeAbstraiteConclusion::FormeAbstraiteConclusion( const std::string & nom ):
            FormeAbstraite( nom )
        { }

    }
}
