Pour compiler les fichier tapez : 
    cmake -G"Unix Makefiles"
    make

par exemple : 
    ./bin/client lorraine.txt

Pour générer la documentation tapez : 
    doxygen

